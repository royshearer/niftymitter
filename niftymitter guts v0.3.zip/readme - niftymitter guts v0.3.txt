Niftymitter Guts v0.3
---------------------------------
CONTENTS
---------------------------------

Documentation:

* Niftymitter Guts Parts List v0.3 [.xls]

* Assembly Instructions [.pdf and at instructables.com]
          o Assembling the Niftymitter 0.24 board 
[http://www.instructables.com/id/Assembling-a-Niftymitter-board-a-short-range-FM-/]
          o Assembling a Niftymitter 0.24 
[http://www.instructables.com/id/Assembling-a-Niftymitter-v024/]
	  o Upgrading a Niftymitter 0.24 PCB to Guts v0.3 [.pdf and .png diagram]
[http://www.instructables.com/id/Upgrading-a-Niftymitter-024-PCB-to-Guts-v03/]

* How to Operate Niftymitter 0.24
[http://www.instructables.com/id/How-to-Operate-Niftymitter-024/]
--------------------------------------------------

Physical:

* Niftymitter guts 3D pack v0.3 [.zip containing .stl and Solidworks]

* Niftymitter Guts Housing Layouts v0.3 [.zip containing .ai and .svg]

----------------------------------------------------

Electronics:

* Niftymitter PCB Layout v0.24 [.png]

          o The PCB source is designed for etching onto copperplate, using iron on acetate (such as that described here http://www.instructables.com/id/Mostly-easy-PCB-manufacture/) or using Michael Shorter's laser engraving method described here http://www.instructables.com/id/Printed-Circuit-Boards-PCB-using-the-Laser-Cutte/ [instructables].

* Niftymitter v0.24 Circuit assembly [.png]

* Niftymitter v0.24 PCB layout and circuit assembly[.svg]

* Basic Electronic Schematics, parts and assembly instructions are here http://anarchy.translocal.jp/radio/micro/simplestTX01.jpg  [Tetsuo Kogawa's site]

          o General support for the electronics is on Kogawa's site here [http://anarchy.translocal.jp/radio/micro/howtosolder/howtosolder.html]. Tetsuo Kogawa's site contains all the information needed to source components and assemble the electronics using his particular copperplate method.

    * Niftymitter v0.3 electronics Schematic [eagle .sch and .png]

-----------------------------------------------------
Updates from v0.24

    * Parts list updated with costs and Rapid online part numbers/links.
    * Trimcap omission in parts list fixed.
    * 3D models added
* Volume control added
*Updated schematics
   
